package test3;

public @interface Anno6 {
    String[] str1() default {};
    String[] str2();
}
