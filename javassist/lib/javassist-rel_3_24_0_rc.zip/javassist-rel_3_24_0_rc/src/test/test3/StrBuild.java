package test3;

public class StrBuild {
    public int test() {
        StringBuilder sb = new StringBuilder("test");
        return sb.charAt(0);
    }
}
