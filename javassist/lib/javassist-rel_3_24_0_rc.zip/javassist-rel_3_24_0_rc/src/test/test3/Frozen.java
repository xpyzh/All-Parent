package test3;

public class Frozen {
    int value;
    public Frozen() { value = 3; }
    public int get() { return value; }
}
