package test1;

public class NewInterface {
    public int foo() { return 3; }
}
